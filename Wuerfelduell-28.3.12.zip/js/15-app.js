  function applyStoredSettings(){
    animationSetting.value=saveData.settings.animation==="fast"?"fast":"normal";
    const fast=animationSetting.value==="fast";
    ROLL_ANIM_MS=fast?250:430;
    document.body.classList.toggle("fast-animations",fast);
    botSpeedMode=["slow","normal","fast"].includes(saveData.settings.botSpeed)?saveData.settings.botSpeed:"normal";
    botSpeedSetting.value=botSpeedMode;
  }

  function hideFrontScreens(){
    [mainMenu,campaignScreen,duoCampaignScreen,trioCampaignScreen,setup,profilesScreen,prestigeShopScreen,achievementsScreen,statsScreen,settingsScreen,rulesScreen,changelogScreen,abilitiesScreen,$("accountScreen")].forEach(el=>el?.classList.add("hidden"));
    document.documentElement.classList.remove("wd-front-scroll-lock");
  }

  function gameIsActivelyRunning(){
    return !game.classList.contains("hidden")
      && winnerBox.classList.contains("hidden")
      && nextRoundBox.classList.contains("hidden");
  }

  function requestLeaveCurrentGame(){
    if(game.classList.contains("hidden")) return false;
    clearBotAutomation();
    quitModal.classList.remove("hidden");
    return true;
  }

  function openMainMenu(force=false){
    if(!force && gameIsActivelyRunning()){
      requestLeaveCurrentGame();
      return;
    }
    clearBotAutomation();
    tutorialMode=false;
    campaignMode=false;
    duoCampaignMode=false;
    trioCampaignMode=false;
    campaignEncounterId=null;
    campaignProfileId=null;
    campaignMetrics=freshCampaignMetrics();
    gameContext={mode:"menu",returnScreen:"menu",profileId:null,encounterId:null};
    resetTutorialUi();
    quitModal.classList.add("hidden");
    campaignModePicker?.classList.add("hidden");
    nextRoundPrepBtn.classList.remove("hidden");
    restartBtn.textContent="Neue Partie";
    rotatingBoard.style.transform="rotate(0deg) scale(1)";
    document.body.classList.remove("playing","bot-acting");
    game.classList.add("hidden");
    game.classList.remove("campaign-game","trio-game");
    winnerBox.classList.add("hidden");
    nextRoundBox.classList.add("hidden");
    hideFrontScreens();
    mainMenu.classList.remove("hidden");
    window.scrollTo?.(0,0);
  }

  // Online-Layer darf nach einem beendeten Match sauber ins Hauptmenü zurückkehren,
  // ohne die interne Menü-/Game-Cleanup-Logik zu duplizieren.
  window.WDAppNav=Object.freeze({openMainMenu,requestLeaveCurrentGame});

  function layoutContainedScreen(screen){
    if(!screen || screen.classList.contains("hidden")) return;
    const inner = screen.querySelector(":scope > .screen-scroll-inner") || screen;
    const topbar = inner.querySelector(".screen-topbar");
    const sub = inner.querySelector(".screen-subtitle");
    const body = inner.querySelector(".ability-list, .screen-scroll-body, .menu-list");
    if(!body) return;
    const used = (topbar ? topbar.offsetHeight : 0) + (sub ? sub.offsetHeight : 0);
    const extra = screen === rulesScreen ? (inner.querySelector(".rules-extra")?.offsetHeight || 0) : 0;
    const available = Math.max(120, inner.clientHeight - used - extra);
    body.style.maxHeight = available + "px";
    body.style.overflowY = "auto";
    body.style.webkitOverflowScrolling = "touch";
  }

  function openFrontScreen(screen){
    document.body.classList.remove("playing","bot-acting");
    game.classList.add("hidden");
    hideFrontScreens();
    screen.classList.remove("hidden");
    window.scrollTo?.(0,0);
    const contained = screen===abilitiesScreen || screen===changelogScreen || screen===rulesScreen || screen===statsScreen || screen===settingsScreen;
    document.documentElement.classList.toggle("wd-front-scroll-lock", contained);
    if(contained) requestAnimationFrame(()=>layoutContainedScreen(screen));
  }

  $("menuCampaignBtn").onclick=()=>{campaignModePicker.classList.remove("hidden");};
  campaignModePickerClose.onclick=()=>campaignModePicker.classList.add("hidden");
  campaignModePicker.onclick=e=>{if(e.target===campaignModePicker)campaignModePicker.classList.add("hidden");};
  campaignModeSoloBtn.onclick=()=>{campaignModePicker.classList.add("hidden");openCampaignScreen();};
  campaignModeDuoBtn.onclick=()=>{campaignModePicker.classList.add("hidden");openDuoCampaignScreen();};
  campaignModeTrioBtn.onclick=()=>{campaignModePicker.classList.add("hidden");openTrioCampaignScreen();};
  $("menuPlayBtn").onclick=()=>{
    tutorialMode=false;
    resetTutorialUi();
    nextRoundPrepBtn.classList.remove("hidden");
    restartBtn.textContent="Neue Partie";
    makeNameFields();
    openFrontScreen(setup);
  };
  $("menuTutorialBtn").onclick=startTutorial;
  campaignBackBtn.onclick=openMainMenu;
  duoCampaignBackBtn.onclick=openMainMenu;
  trioCampaignBackBtn.onclick=openMainMenu;
  duoProfile1Select.onchange=()=>{duoProfile1Id=duoProfile1Select.value||null;duoCampaignEncounterId=null;renderDuoCampaign();};
  duoProfile2Select.onchange=()=>{duoProfile2Id=duoProfile2Select.value||null;duoCampaignEncounterId=null;renderDuoCampaign();};
  duoAbility1Select.onchange=()=>{};duoAbility2Select.onchange=()=>{};
  duoCampaignStartBtn.onclick=startDuoCampaignEncounter;
  duoCampaignProfilesBtn.onclick=()=>{profileScreenOrigin="duo";renderProfiles();openFrontScreen(profilesScreen);};
  trioProfile1Select.onchange=()=>{trioProfile1Id=trioProfile1Select.value||null;trioCampaignEncounterId=null;renderTrioCampaign();};
  trioProfile2Select.onchange=()=>{trioProfile2Id=trioProfile2Select.value||null;trioCampaignEncounterId=null;renderTrioCampaign();};
  trioProfile3Select.onchange=()=>{trioProfile3Id=trioProfile3Select.value||null;trioCampaignEncounterId=null;renderTrioCampaign();};
  trioAbility1Select.onchange=renderTrioCampaign;trioAbility2Select.onchange=renderTrioCampaign;trioAbility3Select.onchange=renderTrioCampaign;
  trioCampaignStartBtn.onclick=startTrioCampaignEncounter;
  trioCampaignProfilesBtn.onclick=()=>{profileScreenOrigin="trio";renderProfiles();openFrontScreen(profilesScreen);};
  campaignProfileSelect.onchange=()=>{campaignProfileId=campaignProfileSelect.value||null;campaignEncounterId=null;gameContext.profileId=campaignProfileId;gameContext.encounterId=null;renderCampaign();};
  campaignAbilitySelect.onchange=()=>renderCampaign();
  campaignStartBtn.onclick=startCampaignEncounter;
  campaignProfilesBtn.onclick=()=>{profileScreenOrigin="campaign";renderProfiles();openFrontScreen(profilesScreen);};
  $("menuProfilesBtn").onclick=()=>{profileScreenOrigin="menu";renderProfiles();openFrontScreen(profilesScreen);};
  $("menuAccountBtn").onclick=()=>{window.WDCloudAccount?.open?.(openFrontScreen);};
  $("accountBackBtn").onclick=openMainMenu;
  $("menuAchievementsBtn").onclick=()=>{renderAchievements();openFrontScreen(achievementsScreen);};
  $("menuPrestigeShopBtn").onclick=()=>{renderPrestigeShop();openFrontScreen(prestigeShopScreen);};
  prestigeShopBackBtn.onclick=openMainMenu;
  prestigeShopProfileSelect.onchange=renderPrestigeShop;
  $("menuStatsBtn").onclick=()=>{renderStats();openFrontScreen(statsScreen);};
  $("menuSettingsBtn").onclick=()=>openFrontScreen(settingsScreen);
  $("menuRulesBtn").onclick=()=>openFrontScreen(rulesScreen);
  $("menuChangelogBtn").onclick=()=>openFrontScreen(changelogScreen);
  tutorialContinueBtn.onclick=closeTutorialStep;

  gameMenuBtn.onclick=()=>requestLeaveCurrentGame();

  quitCancelBtn.onclick=()=>{
    quitModal.classList.add("hidden");
    scheduleBotAction(100);
  };

  quitConfirmBtn.onclick=()=>{
    quitModal.classList.add("hidden");
    if(gameContext.returnScreen==="trio" || trioCampaignMode){returnToTrioCampaignMap();return;}
    if(gameContext.returnScreen==="duo" || duoCampaignMode){returnToDuoCampaignMap();return;}
    if(campaignMode || gameContext.returnScreen==="campaign"){openCampaignScreen();return;}
    openMainMenu(true);
  };

  $("setupBackBtn").onclick=openMainMenu;
  document.querySelectorAll(".menuBackBtn").forEach(btn=>btn.onclick=openMainMenu);

  animationSetting.onchange=()=>{
    const fast=animationSetting.value==="fast";
    ROLL_ANIM_MS=fast?250:430;
    document.body.classList.toggle("fast-animations",fast);
    saveData.settings.animation=animationSetting.value;saveGameData();
  };

  botSpeedSetting.onchange=()=>{ botSpeedMode=botSpeedSetting.value; saveData.settings.botSpeed=botSpeedMode; saveGameData(); };


  createProfileBtn.onclick=()=>{
    const p=createProfile(newProfileName.value);
    if(!p) return;
    newProfileName.value="";renderProfiles();renderAchievements();makeNameFields();
  };
  newProfileName.addEventListener("keydown",e=>{if(e.key==="Enter")createProfileBtn.click();});
  profilesBackBtn.onclick=()=>{
    if(profileScreenOrigin==="setup"){makeNameFields();openFrontScreen(setup);}
    else if(profileScreenOrigin==="campaign"){openCampaignScreen();}
    else if(profileScreenOrigin==="duo"){openDuoCampaignScreen();}
    else if(profileScreenOrigin==="trio"){openTrioCampaignScreen();}
    else openMainMenu();
  };

  $("setupProfilesBtn").onclick=()=>{profileScreenOrigin="setup";renderProfiles();openFrontScreen(profilesScreen);};

  function refreshPersistentUi(){
    applyStoredSettings();renderProfiles();renderAchievements();renderStats();makeNameFields();renderCampaign();renderDuoCampaign();renderTrioCampaign();if(prestigeShopScreen&&!prestigeShopScreen.classList.contains("hidden"))renderPrestigeShop();
  }

  // V27.6.5: Save Import/Export entfernt. Browser-Save bleibt ausschließlich lokal.

  resetStorageBtn.onclick=()=>{
    if(!confirm("Wirklich ALLE lokalen DiceDuel-Profile, Kampagnenfortschritte, Achievements und Statistiken löschen?")) return;
    try{
      clearSaveBackups();
      localStorage.removeItem(SAVE_KEY);
    }catch(e){}
    saveData=createDefaultSave();saveGameData();gameContext={mode:"menu",returnScreen:"menu",profileId:null,encounterId:null};refreshPersistentUi();
  };

  allAbilitiesBtn.onclick=()=>{
    renderAllAbilities();
    openFrontScreen(abilitiesScreen);
  };

  abilitiesBackBtn.onclick=()=>openFrontScreen(rulesScreen);

  $("makeNames").onclick=makeNameFields;
  playerCount.onchange=makeNameFields;
  localModeSelect.onchange=applyLocalModeSetup;
  rollAbilitiesBtn.onclick=rollSetupAbilities;

  startGameBtn.onclick=()=>{
    tutorialMode=false;campaignMode=false;duoCampaignMode=false;trioCampaignMode=false;
    const rules=localModeRules();
    gameContext={mode:`local-${rules.id}`,returnScreen:"setup",profileId:null,encounterId:null};
    resetTutorialUi();nextRoundPrepBtn.classList.remove("hidden");restartBtn.textContent="Neue Partie";
    const n=+playerCount.value;if(setupAbilityRolls.some(v=>v==null)) return;if(!rules.allowBots && n>4) return;

    clearBotAutomation();
    const seats=Array.from({length:n},(_,i)=>+$("seatChoice"+i).value);
    const botLevels=Array.from({length:n},(_,i)=>rules.allowBots?setupBotLevel(i):"human");

    players=Array.from({length:n},(_,i)=>{
      const abilities=getSetupAbilities(i);
      const rolled=setupAbilityRolls[i];
      const profile=botLevels[i]==="human"?getProfile($("profileChoice"+i)?.value):null;
      return{
        name:profile?.name||`Bot ${i+1}`,battleTag:profile?`#${profile.tagNumber}`:"",profileId:profile?.id||null,botLevel:botLevels[i],
        hp:rules.startHp,maxHp:rules.startHp,ability:abilities[0]??1,secondAbility:abilities[1]??null,thirdAbility:abilities[2]??null,
        secondAbilityUnlocked:rules.startAbilityCount>=2,thirdAbilityUnlocked:rules.startAbilityCount>=3,rolledAbility:rolled,
        primaryWasChosen:rules.id==="classic"&&rolled===6,secondAbilityWasChosen:false,thirdAbilityWasChosen:false,
        seat:seats[i],diceDesign:profile?.selectedDice||"classic",...(profile?playerCosmeticsFromProfile(profile):{}),wins:0,momentumStreak:0,lastStandUsed:false,roundLastStandTriggered:false,damageSinceLastOwnTurn:false,bloodRushPrimed:false,voluntaryHpPaidThisTurn:false,botBloodUsesThisAttack:0
      };
    });

    randomizePlayerOrder(false);resetRoundStats();current=0;prepareBloodRushForTurn(current);dice=freshDice();phase="idle";isAnimating=false;
    attackFace=null;attackTarget=null;pendingCampaignAttackStart=null;attackHits=0;attackDamage=0;firstAttackRoll=true;currentAttackRollNewHits=0;
    baseRerollUsed=false;luckRerollIndex=null;luckRerollSecondUsed=false;luckRerollUses=0;loadedDiceUsed=false;loadedDiceUses=0;lastBaseRollIndices=[];attackPowerUsed=false;attackPowerUses=0;precisionUses=0;momentumBonus=0;bloodPriceNeighbors=[];bloodPricePaidThisRoll=0;bloodPriceWasPreActivatedThisRoll=false;bloodRushActiveThisAttack=false;doubleTapApplied=false;attackMasteryRollCount=0;normalAttackHitsThisAttack=0;exactFaceHitsThisAttack=0;wildcardAttackHitsThisAttack=0;wildcardTriggeredThisAttack=false;masteryL2AttackBonusesApplied=false;pendingDamage=null;pendingHeal=null;
    roundNumber=1;roundEliminationOrder=[];lastPlaceIndex=null;roundWinnerHandled=false;roundWinnerIndex=null;nextRoundAbilityRolls=[];eventPopupQueue=[];eventPopupBusy=false;secondAbilityDraftBusy=false;secondAbilityDraftIndex=null;secondAbilityDraftSlot=2;deferredBaseAdvance=false;gamblingRolling=false;gamblingBaseTotal=null;gamblingModal.classList.add("hidden");highStakesRolling=false;highStakesDecisionThisAttack=false;highStakesModal.classList.add("hidden");perfect25Rolling=false;perfect25D4Rolling=false;perfect25BaseTotal=null;pendingPerfect25Total=null;perfect25Modal.classList.add("hidden");perfect25D4Modal.classList.add("hidden");insuranceRolling=false;insuranceContext=null;insuranceModal.classList.add("hidden");counterRolling=false;counterContext=null;counterDiceState=[];counterHits=0;counterFirstRoll=true;pendingCounterattack=null;deferredAttackFinish=false;counterModal.classList.add("hidden");wildcardFace=null;secondAbilityDraftQueue=[];secondAbilityModal.classList.add("hidden");
    logEl.innerHTML="";winnerBox.classList.add("hidden");nextRoundBox.classList.add("hidden");hideFrontScreens();game.classList.remove("hidden","campaign-game","trio-game");document.body.classList.add("playing");window.scrollTo?.(0,0);

    if(rules.id==="classic") addLog(`Classic gestartet mit ${n} Teilnehmern. Jeder startet mit ${rules.startHp} Leben.`);
    else addLog(`${rules.name} gestartet: ${n} lokale Spieler · ${rules.startHp} HP · ${rules.startAbilityCount} Startfähigkeiten · keine Bots.`);
    players.forEach((p,i)=>{
      if(rules.id==="classic"){
        const roll=p.rolledAbility;const abilityText=roll===6?`W25 = 6 → freie Wahl → ${ABILITIES[p.ability].name}`:`W25 = ${roll} → ${ABILITIES[p.ability].name}`;
        const controller=p.botLevel==="human"?"Mensch":BOT_LEVELS[p.botLevel].name;addLog(`${p.name}: ${abilityText} · ${controller} · Sitz: ${SEATS[p.seat].name}.`);
      }else{
        addLog(`${p.name}: ${playerAbilities(i).map(id=>ABILITIES[id].name).join(" + ")}.`);
      }
    });
    renderAll();
  };

  gamblingDie.onclick=()=>{if(!isBotPlayer(current))rollGamblingMan();};
  if(gamblingRetryBtn) gamblingRetryBtn.onclick=()=>{if(!isBotPlayer(current))startGamblingRetry();};
  if(gamblingRetryEndBtn) gamblingRetryEndBtn.onclick=()=>{if(!isBotPlayer(current))declineGamblingRetry();};
  perfect25Die.onclick=()=>{if(!isBotPlayer(current))rollPerfect25();};
  perfect25D4Die.onclick=()=>{if(!isBotPlayer(current))rollPerfect25D4();};
  highStakesDie.onclick=()=>{if(!isBotPlayer(current))rollHighStakes();};
  highStakesSkip.onclick=()=>{if(!isBotPlayer(current))skipHighStakes();};

  primaryBtn.onclick=()=>{
    if(isBotPlayer(current)) return;
    if(phase==="idle"||phase==="base_ready") rollBase();
    else if(phase==="attack_ready"||phase==="attack_continue") rollAttack();
    else if(phase==="attack_after_roll"&&hasAbility(24)&&attackHits===2&&currentAttackRollNewHits>0) continueDoubleTapAttack();
  };
  lockBtn.onclick=()=>{if(!isBotPlayer(current))lockSelected();};
  baseRerollBtn.onclick=()=>{if(!isBotPlayer(current))useBaseReroll();};
  loadedDiceBtn.onclick=()=>{if(!isBotPlayer(current))useLoadedDice();};
  snakeEyesBtn.onclick=()=>{if(!isBotPlayer(current))useSnakeEyes();};
  insuranceDie.onclick=()=>{if(!isBotPlayer(current))rollInsurance();};
  counterRollBtn.onclick=()=>{
    if(!counterContext) return;
    if(isBotPlayer(counterContext.defenderIndex)) return;
    document.body.classList.remove("bot-acting");
    if(!counterRolling) counterRollBtn.disabled=false;
    rollCounterattack();
  };
  attackPowerBtn.onclick=()=>{if(!isBotPlayer(current))useAttackPower();};
  bloodLowerBtn.onclick=()=>{if(!isBotPlayer(current))useBloodPrice();};
  bloodRushMasteryBtn.onclick=()=>{if(!isBotPlayer(current))useBloodRushSelfHarm();};
  bloodHigherBtn.onclick=()=>{if(!isBotPlayer(current))useBloodPrice();};
  resolveAttackBtn.onclick=()=>{if(!isBotPlayer(current))resolveCurrentAttackRoll();};
  nextBtn.onclick=()=>{if(!isBotPlayer(current))advanceTurn();};
  nextRoundPrepBtn.onclick=prepareNextRound;
  startNextRoundBtn.onclick=startNextRound;

  restartBtn.onclick=()=>{
    if(trioCampaignMode || gameContext.returnScreen==="trio" || restartBtn.textContent==="Zur Trio-Kampagne"){returnToTrioCampaignMap();return;}
    if(duoCampaignMode || gameContext.returnScreen==="duo" || restartBtn.textContent==="Zur Duo-Kampagne"){returnToDuoCampaignMap();return;}
    if(campaignMode || gameContext.returnScreen==="campaign" || restartBtn.textContent==="Zur Kampagne"){
      returnToCampaignMap();
      return;
    }
    if(tutorialMode){
      openMainMenu();
      return;
    }
    clearBotAutomation();
    rotatingBoard.style.transform="rotate(0deg) scale(1)";
    eventPopupQueue=[];eventPopupBusy=false;
    secondAbilityDraftBusy=false;secondAbilityDraftIndex=null;deferredBaseAdvance=false;
    gamblingRolling=false;gamblingBaseTotal=null;gamblingModal.classList.add("hidden");highStakesRolling=false;highStakesDecisionThisAttack=false;highStakesModal.classList.add("hidden");perfect25Rolling=false;perfect25D4Rolling=false;perfect25BaseTotal=null;pendingPerfect25Total=null;perfect25Modal.classList.add("hidden");perfect25D4Modal.classList.add("hidden");insuranceRolling=false;insuranceContext=null;insuranceModal.classList.add("hidden");counterRolling=false;counterContext=null;counterDiceState=[];counterHits=0;counterFirstRoll=true;pendingCounterattack=null;deferredAttackFinish=false;counterModal.classList.add("hidden");wildcardFace=null;secondAbilityDraftQueue=[];
    secondAbilityModal.classList.add("hidden");
    eventPopup.classList.remove("active","death","win","survive");
    winnerBox.classList.add("hidden");nextRoundBox.classList.add("hidden");
    document.body.classList.remove("playing","bot-acting");
    game.classList.add("hidden");
    gameContext={mode:"setup",returnScreen:"setup",profileId:null,encounterId:null};
    makeNameFields();
    openFrontScreen(setup);
  };

  window.addEventListener("resize",()=>{
    if(!game.classList.contains("hidden")) applySeatRotation();
    const open=[abilitiesScreen,changelogScreen,rulesScreen,statsScreen,settingsScreen].find(el=>el && !el.classList.contains("hidden"));
    if(open) layoutContainedScreen(open);
  });

  loadSaveData();
  applyStoredSettings();
  renderProfiles();
  renderAchievements();
  renderStats();
  applyLocalModeSetup();
  renderCampaign();
  renderDuoCampaign();
  renderTrioCampaign();
  openMainMenu();
