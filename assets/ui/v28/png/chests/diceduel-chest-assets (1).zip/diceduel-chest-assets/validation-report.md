# DiceDuel chest asset validation

All tolerances are the fixed values from the brief.

| stage | file | px | bbox alpha>8 | center x | corner alpha | halo px | VP8X/ALPH | composite MAD | result |
|---|---|---:|---|---:|---:|---:|---|---:|---|
| common | chest-card-front-common.webp | 512×704 | (15, 15, 496, 688) | 255.5 | 0 |  | yes |  | PASS |
| common | chest-common-body.webp | 512×512 | (56, 200, 456, 452) | 256.0 | 0 | 2.0 | yes |  | PASS |
| common | chest-common-closed.webp | 512×512 | (56, 92, 456, 452) | 256.0 | 0 | 2.0 | yes | 0.00422758 | PASS |
| common | chest-common-lid-inner.webp | 512×512 | (56, 92, 456, 252) | 256.0 | 0 | 2.0 | yes |  | PASS |
| common | chest-common-lid.webp | 512×512 | (56, 92, 456, 252) | 256.0 | 0 | 2.0 | yes |  | PASS |
| common | chest-common-light.webp | 512×512 | (30, 4, 482, 456) | 256.0 | 0 |  | yes |  | PASS |
| common | chest-common-open.webp | 512×512 | (28, 24, 483, 457) | 255.5 | 0 |  | yes |  | PASS |
| common | chest-common-rays.webp | 1024×1024 | (93, 96, 930, 927) | 511.5 | 0 |  | yes |  | PASS |
| rare | chest-card-front-rare.webp | 512×704 | (15, 15, 496, 688) | 255.5 | 0 |  | yes |  | PASS |
| rare | chest-rare-body.webp | 512×512 | (56, 200, 456, 452) | 256.0 | 0 | 2.0 | yes |  | PASS |
| rare | chest-rare-closed.webp | 512×512 | (56, 92, 456, 452) | 256.0 | 0 | 2.0 | yes | 0.00341852 | PASS |
| rare | chest-rare-lid-inner.webp | 512×512 | (56, 92, 456, 252) | 256.0 | 0 | 2.0 | yes |  | PASS |
| rare | chest-rare-lid.webp | 512×512 | (56, 92, 456, 252) | 256.0 | 0 | 2.0 | yes |  | PASS |
| rare | chest-rare-light.webp | 512×512 | (30, 4, 482, 456) | 256.0 | 0 |  | yes |  | PASS |
| rare | chest-rare-open.webp | 512×512 | (28, 24, 483, 457) | 255.5 | 0 |  | yes |  | PASS |
| rare | chest-rare-rays.webp | 1024×1024 | (93, 96, 930, 927) | 511.5 | 0 |  | yes |  | PASS |
| epic | chest-card-front-epic.webp | 512×704 | (15, 15, 496, 688) | 255.5 | 0 |  | yes |  | PASS |
| epic | chest-epic-body.webp | 512×512 | (56, 200, 456, 452) | 256.0 | 0 | 2.0 | yes |  | PASS |
| epic | chest-epic-closed.webp | 512×512 | (56, 92, 456, 452) | 256.0 | 0 | 2.0 | yes | 0.00403022 | PASS |
| epic | chest-epic-lid-inner.webp | 512×512 | (56, 92, 456, 252) | 256.0 | 0 | 2.0 | yes |  | PASS |
| epic | chest-epic-lid.webp | 512×512 | (56, 92, 456, 252) | 256.0 | 0 | 2.0 | yes |  | PASS |
| epic | chest-epic-light.webp | 512×512 | (30, 4, 482, 456) | 256.0 | 0 |  | yes |  | PASS |
| epic | chest-epic-open.webp | 512×512 | (28, 24, 483, 457) | 255.5 | 0 |  | yes |  | PASS |
| epic | chest-epic-rays.webp | 1024×1024 | (93, 96, 930, 927) | 511.5 | 0 |  | yes |  | PASS |
| legendary | chest-card-front-legendary.webp | 512×704 | (15, 15, 496, 688) | 255.5 | 0 |  | yes |  | PASS |
| legendary | chest-legendary-body.webp | 512×512 | (56, 200, 456, 452) | 256.0 | 0 | 2.0 | yes |  | PASS |
| legendary | chest-legendary-closed.webp | 512×512 | (56, 92, 456, 452) | 256.0 | 0 | 2.0 | yes | 0.00360118 | PASS |
| legendary | chest-legendary-lid-inner.webp | 512×512 | (56, 92, 456, 252) | 256.0 | 0 | 2.0 | yes |  | PASS |
| legendary | chest-legendary-lid.webp | 512×512 | (56, 92, 456, 252) | 256.0 | 0 | 2.0 | yes |  | PASS |
| legendary | chest-legendary-light.webp | 512×512 | (30, 4, 482, 456) | 256.0 | 0 |  | yes |  | PASS |
| legendary | chest-legendary-open.webp | 512×512 | (28, 24, 483, 457) | 255.5 | 0 |  | yes |  | PASS |
| legendary | chest-legendary-rays.webp | 1024×1024 | (93, 96, 930, 927) | 511.5 | 0 |  | yes |  | PASS |
| shared | chest-card-back.webp | 512×704 | (15, 15, 496, 688) |  | 0 |  | yes |  | PASS |
| shared | chest-shadow.webp | 512×256 | (70, 73, 441, 182) |  | 0 |  | yes |  | PASS |
| shared | chest-sparkle.webp | 128×128 | (9, 10, 118, 118) |  | 0 |  | yes |  | PASS |
