#!/usr/bin/env python3
from __future__ import annotations

import csv
import hashlib
import io
import json
import math
import os
import random
import shutil
import struct
import sys
import zipfile
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageFont
from scipy.ndimage import distance_transform_edt


ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "output" / "diceduel-chest-assets"
ASSET_ROOT = OUT / "assets" / "ui" / "v28" / "png" / "chests"
SRC_ROOT = ASSET_ROOT / "src"
PREVIEW_ROOT = OUT / "control-composites"

STAGES = ("common", "rare", "epic", "legendary")
STAGE_COLORS = {
    "common": (232, 217, 176),
    "rare": (74, 143, 240),
    "epic": (176, 108, 255),
    "legendary": (255, 212, 90),
}

GOLD_STOPS = (
    (0.00, "#fff4bf"),
    (0.25, "#f6d679"),
    (0.50, "#c98a26"),
    (0.72, "#ffe59a"),
    (1.00, "#9a5d16"),
)
NAVY_STOPS = ((0.0, "#245da9"), (1.0, "#0d3975"))

REGULAR_SIZE = (512, 512)
REGULAR_SOURCE = (1024, 1024)
RAYS_SIZE = (1024, 1024)
RAYS_SOURCE = (2048, 2048)
CARD_SIZE = (512, 704)
CARD_SOURCE = (1024, 1408)

# Render at 4x target size. PNG source is derived at 2x; WebP at 1x.
SS = 4


def rgba(hex_color: str, alpha: int = 255) -> tuple[int, int, int, int]:
    h = hex_color.lstrip("#")
    return tuple(int(h[i : i + 2], 16) for i in (0, 2, 4)) + (alpha,)


def lerp(a, b, t):
    return a + (b - a) * t


def atomic_write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("wb") as handle:
        handle.write(data)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(tmp, path)


def scale_box(box, factor=SS):
    return tuple(int(round(v * factor)) for v in box)


def scale_points(points, factor=SS):
    return [(int(round(x * factor)), int(round(y * factor))) for x, y in points]


def mask_image(size=REGULAR_SIZE):
    return Image.new("L", (size[0] * SS, size[1] * SS), 0)


def vertical_gradient(size, stops):
    parsed = [(p, np.array(rgba(c)[:3], dtype=np.float32)) for p, c in stops]
    h, w = size[1], size[0]
    arr = np.zeros((h, w, 4), dtype=np.uint8)
    ys = np.linspace(0, 1, h)
    for y, t in enumerate(ys):
        for idx in range(len(parsed) - 1):
            p0, c0 = parsed[idx]
            p1, c1 = parsed[idx + 1]
            if p0 <= t <= p1 or idx == len(parsed) - 2:
                u = min(1.0, max(0.0, (t - p0) / max(1e-9, p1 - p0)))
                arr[y, :, :3] = np.clip(c0 * (1 - u) + c1 * u, 0, 255).astype(np.uint8)
                break
    arr[:, :, 3] = 255
    return Image.fromarray(arr, "RGBA")


def material_texture(stage: str, size, kind="main"):
    w, h = size
    y, x = np.mgrid[0:h, 0:w]
    xn = (x - w / 2) / max(w, 1)
    yn = y / max(h - 1, 1)
    rng = np.random.default_rng(100 + STAGES.index(stage) * 31 + (3 if kind == "inner" else 0))
    noise = rng.normal(0, 1, (h, w))
    light = np.clip(1.12 - 0.34 * yn + 0.12 * (-xn), 0.68, 1.22)

    if stage == "common":
        grain = (
            0.52
            + 0.20 * np.sin(x * 0.036 + 1.4 * np.sin(y * 0.006))
            + 0.11 * np.sin(x * 0.115 + y * 0.009)
            + 0.035 * noise
        )
        base = np.stack(
            [55 + 39 * grain, 27 + 18 * grain, 12 + 8 * grain], axis=2
        )
    elif stage == "rare":
        top = np.array(rgba("#245da9")[:3], dtype=float)
        bot = np.array(rgba("#0d3975")[:3], dtype=float)
        base = top[None, None, :] * (1 - yn[:, :, None]) + bot[None, None, :] * yn[:, :, None]
        vein = 5 * np.sin(x * 0.026 + 2.1 * np.sin(y * 0.008)) + 2 * noise
        base += vein[:, :, None] * np.array([0.55, 0.8, 1.0])
    elif stage == "epic":
        top = np.array(rgba("#7a3fb5")[:3], dtype=float)
        bot = np.array(rgba("#4a2273")[:3], dtype=float)
        base = top[None, None, :] * (1 - yn[:, :, None]) + bot[None, None, :] * yn[:, :, None]
        swirl = 7 * np.sin(x * 0.018 + 2.8 * np.sin(y * 0.011)) + 2 * noise
        base += swirl[:, :, None] * np.array([0.9, 0.48, 1.0])
    else:
        gold = np.array(rgba("#c98a26")[:3], dtype=float)
        hi = np.array(rgba("#ffe59a")[:3], dtype=float)
        band = 0.45 + 0.45 * np.sin(x * 0.021 + 0.7 * np.sin(y * 0.012))
        base = gold[None, None, :] * (1 - band[:, :, None] * 0.32) + hi[None, None, :] * (band[:, :, None] * 0.32)
        base += noise[:, :, None] * 1.6

    if kind == "inner":
        warm = np.array([34, 13, 17], dtype=float) if stage in ("epic", "legendary") else np.array([24, 15, 11], dtype=float)
        base = warm[None, None, :] * (0.82 + 0.18 * light[:, :, None]) + noise[:, :, None] * 1.5
    else:
        base *= light[:, :, None]
    alpha = np.full((h, w, 1), 255.0)
    return Image.fromarray(np.clip(np.concatenate([base, alpha], axis=2), 0, 255).astype(np.uint8), "RGBA")


def apply_mask(texture: Image.Image, mask: Image.Image) -> Image.Image:
    out = texture.copy()
    out.putalpha(mask)
    return out


def metal_gradient(kind: str, size):
    if kind == "gold":
        return vertical_gradient(size, GOLD_STOPS)
    if kind == "silver":
        return vertical_gradient(size, ((0.0, "#f8fbff"), (0.28, "#bdc8d4"), (0.58, "#687787"), (0.76, "#e6edf4"), (1.0, "#566372")))
    return vertical_gradient(size, ((0.0, "#bbc0bd"), (0.25, "#6b706e"), (0.56, "#292e2e"), (0.76, "#777c78"), (1.0, "#202423")))


def stage_metal(stage: str):
    return "iron" if stage == "common" else "silver" if stage == "rare" else "gold"


def paste_shape(canvas, shape_mask, fill):
    if isinstance(fill, tuple):
        layer = Image.new("RGBA", canvas.size, fill)
    else:
        layer = fill
    canvas.alpha_composite(apply_mask(layer, shape_mask))


def draw_stroke(draw, points, fill, width, joint="curve"):
    draw.line(scale_points(points), fill=fill, width=max(1, int(width * SS)), joint=joint)


def body_mask():
    mask = mask_image()
    d = ImageDraw.Draw(mask)
    d.rounded_rectangle(scale_box((56, 218, 456, 438)), radius=12 * SS, fill=255)
    d.polygon(scale_points(((76, 200), (436, 200), (450, 228), (62, 228))), fill=255)
    d.rounded_rectangle(scale_box((56, 424, 98, 452)), radius=7 * SS, fill=255)
    d.rounded_rectangle(scale_box((414, 424, 456, 452)), radius=7 * SS, fill=255)
    return mask


def lid_mask():
    mask = mask_image()
    d = ImageDraw.Draw(mask)
    d.rounded_rectangle(scale_box((56, 92, 456, 240)), radius=55 * SS, fill=255)
    d.rectangle(scale_box((56, 176, 456, 252)), fill=255)
    return mask


def draw_diamond(draw, cx, cy, rx, ry, fill, outline=None, width=2):
    pts = scale_points(((cx, cy - ry), (cx + rx, cy), (cx, cy + ry), (cx - rx, cy)))
    draw.polygon(pts, fill=fill)
    if outline:
        draw.line(pts + [pts[0]], fill=outline, width=width * SS, joint="curve")


def draw_gem(draw, cx, cy, r, color):
    pts = scale_points(((cx, cy - r), (cx + r, cy), (cx, cy + r), (cx - r, cy)))
    dark = tuple(max(0, c - 58) for c in color) + (255,)
    draw.polygon(pts, fill=dark)
    inner = scale_points(((cx, cy - r + 3), (cx + r - 3, cy), (cx, cy + r - 3), (cx - r + 3, cy)))
    draw.polygon(inner, fill=color + (255,))
    draw.line(scale_points(((cx - r + 4, cy), (cx, cy - r + 3), (cx + 2, cy + 1))), fill=(255, 255, 244, 210), width=SS)


def draw_crown(draw, cx, y, color):
    pts = ((cx - 36, y + 24), (cx - 31, y), (cx - 13, y + 14), (cx, y - 8), (cx + 13, y + 14), (cx + 31, y), (cx + 36, y + 24))
    draw.polygon(scale_points(pts), fill=color)
    draw.rounded_rectangle(scale_box((cx - 38, y + 21, cx + 38, y + 34)), radius=4 * SS, fill=color)


def decorate_body(stage: str, canvas: Image.Image):
    draw = ImageDraw.Draw(canvas)
    metal_kind = stage_metal(stage)
    metal = metal_gradient(metal_kind, canvas.size)

    # Dark warm opening, rear wall and front inner rim.
    draw.polygon(scale_points(((79, 207), (433, 207), (445, 228), (67, 228))), fill=(26, 15, 12, 255))
    draw.polygon(scale_points(((68, 220), (444, 220), (424, 260), (88, 260))), fill=(8, 7, 8, 255))
    draw.polygon(scale_points(((72, 229), (440, 229), (427, 247), (85, 247))), fill=(37, 23, 17, 255))

    # Main front material returns below the opening.
    front = Image.new("L", canvas.size, 0)
    fd = ImageDraw.Draw(front)
    fd.rounded_rectangle(scale_box((64, 246, 448, 435)), radius=7 * SS, fill=255)
    paste_shape(canvas, front, material_texture(stage, canvas.size))

    # Legendary ivory enamel inserts.
    if stage == "legendary":
        ivory = rgba("#f3e9d2")
        draw.rounded_rectangle(scale_box((94, 270, 232, 408)), radius=20 * SS, fill=ivory, outline=rgba("#9a5d16"), width=3 * SS)
        draw.rounded_rectangle(scale_box((280, 270, 418, 408)), radius=20 * SS, fill=ivory, outline=rgba("#9a5d16"), width=3 * SS)

    # Horizontal and corner metal parts use the declared material gradient.
    shapes = Image.new("L", canvas.size, 0)
    sd = ImageDraw.Draw(shapes)
    sd.rounded_rectangle(scale_box((56, 232, 456, 253)), radius=5 * SS, fill=255)
    sd.rounded_rectangle(scale_box((56, 420, 456, 440)), radius=5 * SS, fill=255)
    for x0 in (56, 424):
        sd.rounded_rectangle(scale_box((x0, 220, x0 + 32, 438)), radius=5 * SS, fill=255)
    sd.rounded_rectangle(scale_box((56, 424, 98, 452)), radius=7 * SS, fill=255)
    sd.rounded_rectangle(scale_box((414, 424, 456, 452)), radius=7 * SS, fill=255)
    paste_shape(canvas, shapes, metal)

    # Symmetric painted ornament on the front face.
    ornament_color = (45, 47, 45, 255) if stage == "common" else (226, 236, 244, 255) if stage == "rare" else (255, 230, 154, 255)
    for side in (-1, 1):
        cx = 256 + side * 105
        box = scale_box((cx - 50, 286, cx + 50, 392))
        draw.arc(box, start=205 if side < 0 else -25, end=515 if side < 0 else 285, fill=ornament_color, width=3 * SS)
        draw.ellipse(scale_box((cx - 4, 336, cx + 4, 344)), fill=ornament_color)

    if stage == "epic":
        for cx, cy in ((76, 270), (436, 270), (76, 410), (436, 410)):
            draw_gem(draw, cx, cy, 10, rgba("#7a3fb5")[:3])
    elif stage == "legendary":
        for cx, cy in ((76, 270), (436, 270), (76, 410), (436, 410)):
            draw_gem(draw, cx, cy, 10, (36, 105, 190))
    elif stage == "common":
        # Subtle rust confined to iron parts, mirrored.
        rust = (121, 57, 25, 255)
        for x in (70, 442):
            draw.ellipse(scale_box((x - 4, 308, x + 4, 318)), fill=rust)
            draw.ellipse(scale_box((x - 3, 373, x + 3, 381)), fill=rust)


def build_body(stage: str):
    mask = body_mask()
    canvas = apply_mask(material_texture(stage, mask.size), mask)
    decorate_body(stage, canvas)
    canvas.putalpha(mask)
    return canvas


def decorate_lid(stage: str, canvas: Image.Image, inner=False):
    draw = ImageDraw.Draw(canvas)
    metal_kind = stage_metal(stage)
    metal = metal_gradient(metal_kind, canvas.size)

    if inner:
        # Interior panel and fully matching outer metal frame.
        draw.rounded_rectangle(scale_box((72, 104, 440, 224)), radius=40 * SS, fill=(22, 12, 16, 255))
        draw.rounded_rectangle(scale_box((88, 119, 424, 212)), radius=28 * SS, outline=(90, 54, 33, 255), width=4 * SS)
    elif stage == "legendary":
        draw.rounded_rectangle(scale_box((76, 105, 436, 216)), radius=40 * SS, fill=rgba("#f3e9d2"))

    # Bands and front fascia.
    shapes = Image.new("L", canvas.size, 0)
    sd = ImageDraw.Draw(shapes)
    sd.rounded_rectangle(scale_box((56, 216, 456, 252)), radius=5 * SS, fill=255)
    for x0 in (70, 424):
        sd.rounded_rectangle(scale_box((x0, 100, x0 + 18, 240)), radius=8 * SS, fill=255)
    sd.rounded_rectangle(scale_box((56, 236, 456, 244)), radius=3 * SS, fill=255)
    sd.rounded_rectangle(scale_box((56, 246, 456, 252)), radius=2 * SS, fill=255)
    paste_shape(canvas, shapes, metal)

    if inner:
        return

    # Lock sits at x=256 on the seam and remains inside the lid silhouette.
    lock_color = rgba("#555b59") if stage == "common" else rgba("#c4d0db") if stage == "rare" else rgba("#c98a26")
    draw_diamond(draw, 256, 236, 25, 17, lock_color, outline=(255, 229, 154, 255) if stage in ("epic", "legendary") else (38, 43, 42, 255), width=2)
    draw.rounded_rectangle(scale_box((250, 237, 262, 252)), radius=3 * SS, fill=lock_color)
    if stage == "rare":
        draw_gem(draw, 256, 235, 7, (36, 105, 190))
    elif stage == "epic":
        draw_gem(draw, 256, 235, 8, rgba("#7a3fb5")[:3])
    elif stage == "legendary":
        draw_gem(draw, 256, 235, 8, rgba("#b8202e")[:3])
        draw_crown(draw, 256, 144, rgba("#c98a26"))

    # Subtle stage-specific motifs stay within the common silhouette.
    motif = (48, 51, 49, 255) if stage == "common" else (220, 231, 242, 255) if stage == "rare" else (255, 229, 154, 255)
    for side in (-1, 1):
        cx = 256 + side * 112
        draw.arc(scale_box((cx - 40, 125, cx + 40, 204)), 20, 340, fill=motif, width=3 * SS)
        draw.ellipse(scale_box((cx - 4, 160, cx + 4, 168)), fill=motif)


def build_lid(stage: str, inner=False):
    mask = lid_mask()
    kind = "inner" if inner else "main"
    canvas = apply_mask(material_texture(stage, mask.size, kind), mask)
    decorate_lid(stage, canvas, inner=inner)
    canvas.putalpha(mask)
    return canvas


def build_light(stage: str):
    w = h = 512 * SS
    cx, cy = 256 * SS, 230 * SS
    yy, xx = np.mgrid[0:h, 0:w]
    r = np.sqrt((xx - cx) ** 2 + (yy - cy) ** 2) / SS
    # Visible core about 360 px diameter; fully gone before radius 240.
    alpha = np.where(r <= 180, 178 * (1 - (r / 205) ** 1.65), 86 * np.maximum(0, 1 - (r - 180) / 52))
    alpha[r >= 236] = 0
    color = np.array(STAGE_COLORS[stage], dtype=np.uint8)
    arr = np.zeros((h, w, 4), dtype=np.uint8)
    arr[:, :, :3] = color
    arr[:, :, 3] = np.clip(alpha, 0, 178).astype(np.uint8)
    return Image.fromarray(arr, "RGBA")


def build_rays(stage: str):
    size = 1024 * 2  # 2x source is exactly the requested PNG source.
    canvas = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    # Draw at source resolution; radial blur provides soft edges.
    layer = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    cx = cy = size // 2
    count = 20
    base = STAGE_COLORS[stage]
    gold = rgba("#f6d679")[:3]
    for i in range(count):
        angle = i * 2 * math.pi / count
        half = math.radians(2.0 if i % 2 else 3.1)
        r0 = 84 * 2
        r1 = (420 if i % 2 else 456) * 2
        p0 = (cx + math.cos(angle - half) * r0, cy + math.sin(angle - half) * r0)
        p1 = (cx + math.cos(angle) * r1, cy + math.sin(angle) * r1)
        p2 = (cx + math.cos(angle + half) * r0, cy + math.sin(angle + half) * r0)
        color = tuple(round((base[k] * 0.68 + gold[k] * 0.32)) for k in range(3)) + (84 if i % 2 else 112,)
        d.polygon((p0, p1, p2), fill=color)
    layer = layer.filter(ImageFilter.GaussianBlur(8))
    arr = np.array(layer)
    yy, xx = np.mgrid[0:size, 0:size]
    r = np.sqrt((xx - cx) ** 2 + (yy - cy) ** 2) / 2
    center_fade = np.clip((r - 72) / 34, 0, 1)
    outer_fade = np.clip((470 - r) / 36, 0, 1)
    border = 52 * 2
    border_mask = np.ones((size, size), dtype=float)
    border_mask[:border] = 0
    border_mask[-border:] = 0
    border_mask[:, :border] = 0
    border_mask[:, -border:] = 0
    arr[:, :, 3] = (arr[:, :, 3].astype(float) * center_fade * outer_fade * border_mask).astype(np.uint8)
    return Image.fromarray(arr, "RGBA")


def open_lid_mask():
    mask = mask_image()
    d = ImageDraw.Draw(mask)
    d.rounded_rectangle(scale_box((74, 24, 438, 238)), radius=24 * SS, fill=255)
    d.rectangle(scale_box((74, 154, 438, 240)), fill=255)
    return mask


def build_open(stage: str, body: Image.Image):
    light = build_light(stage)
    canvas = Image.new("RGBA", body.size, (0, 0, 0, 0))
    canvas.alpha_composite(light)
    om = open_lid_mask()
    ol = apply_mask(material_texture(stage, om.size, "inner"), om)
    d = ImageDraw.Draw(ol)
    metal = metal_gradient(stage_metal(stage), ol.size)
    frame = Image.new("L", ol.size, 0)
    fd = ImageDraw.Draw(frame)
    fd.rounded_rectangle(scale_box((74, 24, 438, 240)), radius=24 * SS, outline=255, width=12 * SS)
    fd.rounded_rectangle(scale_box((91, 42, 421, 221)), radius=16 * SS, outline=255, width=4 * SS)
    fd.rectangle(scale_box((74, 228, 438, 240)), fill=255)
    paste_shape(ol, frame, metal)
    ol.putalpha(om)
    canvas.alpha_composite(ol)
    canvas.alpha_composite(body)
    # Strong inner glow is allowed only in open.
    glow = build_light(stage).crop(scale_box((0, 0, 512, 512))).resize(canvas.size)
    glow.putalpha(glow.getchannel("A").point(lambda a: int(a * 0.42)))
    canvas.alpha_composite(glow)
    # Repaint body above the glow for legibility.
    canvas.alpha_composite(body)
    return canvas


def build_closed(body: Image.Image, lid: Image.Image):
    canvas = Image.new("RGBA", body.size, (0, 0, 0, 0))
    canvas.alpha_composite(body)
    canvas.alpha_composite(lid)
    return canvas


def rounded_card_mask(size=CARD_SIZE):
    mask = Image.new("L", (size[0] * SS, size[1] * SS), 0)
    # A 16 px transparent canvas gutter is required so every 16x16 canvas
    # corner remains fully transparent while the card itself keeps radius 40.
    ImageDraw.Draw(mask).rounded_rectangle(
        (16 * SS, 16 * SS, (size[0] - 16) * SS - 1, (size[1] - 16) * SS - 1),
        radius=40 * SS,
        fill=255,
    )
    return mask


def build_card_back():
    mask = rounded_card_mask()
    canvas = apply_mask(vertical_gradient(mask.size, NAVY_STOPS), mask)
    d = ImageDraw.Draw(canvas)
    gold = rgba("#f6d679")
    dark_gold = rgba("#9a5d16")
    for inset, width in ((18, 6), (31, 2)):
        inset += 16
        d.rounded_rectangle(scale_box((inset, inset, 512 - inset, 704 - inset)), radius=max(12, 40 - (inset - 16) // 2) * SS, outline=gold if inset == 34 else dark_gold, width=width * SS)
    # Symmetric corner ornaments and central stylized die.
    for sx in (-1, 1):
        for sy in (-1, 1):
            cx, cy = 256 + sx * 185, 352 + sy * 270
            d.arc(scale_box((cx - 30, cy - 30, cx + 30, cy + 30)), 0, 330, fill=gold, width=3 * SS)
    d.rounded_rectangle(scale_box((190, 286, 322, 418)), radius=24 * SS, outline=gold, width=7 * SS)
    for cx, cy in ((224, 320), (288, 384), (256, 352), (288, 320), (224, 384)):
        d.ellipse(scale_box((cx - 9, cy - 9, cx + 9, cy + 9)), fill=gold)
    canvas.putalpha(mask)
    return canvas


def build_card_front(stage: str):
    mask = rounded_card_mask()
    if stage == "common":
        canvas = apply_mask(material_texture("common", mask.size), mask)
    elif stage == "rare":
        canvas = apply_mask(vertical_gradient(mask.size, NAVY_STOPS), mask)
    elif stage == "epic":
        canvas = apply_mask(vertical_gradient(mask.size, ((0, "#7a3fb5"), (1, "#4a2273"))), mask)
    else:
        canvas = apply_mask(vertical_gradient(mask.size, ((0, "#f3e9d2"), (1, "#d8c9a8"))), mask)
    d = ImageDraw.Draw(canvas)
    metal_kind = stage_metal(stage)
    border = metal_gradient(metal_kind, canvas.size)
    bm = Image.new("L", canvas.size, 0)
    bd = ImageDraw.Draw(bm)
    bd.rounded_rectangle(scale_box((16, 16, 496, 688)), radius=40 * SS, outline=255, width=18 * SS)
    bd.rounded_rectangle(scale_box((41, 41, 471, 663)), radius=27 * SS, outline=255, width=5 * SS)
    paste_shape(canvas, bm, border)
    # Empty art field and empty name band, exact requested coordinates.
    d.rounded_rectangle(scale_box((64, 64, 448, 448)), radius=18 * SS, fill=(12, 25, 45, 255), outline=(245, 214, 121, 255), width=4 * SS)
    d.rounded_rectangle(scale_box((64, 520, 448, 640)), radius=18 * SS, fill=(12, 25, 45, 235), outline=(245, 214, 121, 255), width=4 * SS)
    if stage == "epic":
        for cx, cy in ((44, 44), (468, 44), (44, 660), (468, 660)):
            draw_gem(d, cx, cy, 9, rgba("#7a3fb5")[:3])
    elif stage == "legendary":
        for cx, cy in ((44, 44), (468, 44), (44, 660), (468, 660)):
            draw_gem(d, cx, cy, 9, (36, 105, 190))
    canvas.putalpha(mask)
    return canvas


def build_shadow():
    w, h = 512 * SS, 256 * SS
    yy, xx = np.mgrid[0:h, 0:w]
    nx = (xx - 256 * SS) / (210 * SS)
    ny = (yy - 128 * SS) / (62 * SS)
    r = nx * nx + ny * ny
    alpha = np.clip(np.clip(1 - r, 0, 1) ** 1.8 * 140, 0, 140)
    alpha[r >= 1] = 0
    arr = np.zeros((h, w, 4), dtype=np.uint8)
    arr[:, :, 3] = alpha.astype(np.uint8)
    return Image.fromarray(arr, "RGBA")


def build_sparkle():
    size = 128 * SS
    canvas = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    layer = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    cx = cy = size // 2
    gold = rgba("#ffe59a")
    d.polygon(((cx, 10 * SS), (cx + 8 * SS, cy - 8 * SS), (cx, size - 10 * SS), (cx - 8 * SS, cy + 8 * SS)), fill=gold)
    d.polygon(((10 * SS, cy), (cx - 8 * SS, cy - 8 * SS), (size - 10 * SS, cy), (cx + 8 * SS, cy + 8 * SS)), fill=gold)
    d.ellipse((cx - 11 * SS, cy - 11 * SS, cx + 11 * SS, cy + 11 * SS), fill=(255, 255, 244, 255))
    blur = layer.filter(ImageFilter.GaussianBlur(6 * SS))
    blur.putalpha(blur.getchannel("A").point(lambda a: int(a * 0.48)))
    canvas.alpha_composite(blur)
    canvas.alpha_composite(layer)
    return canvas


def clean_alpha(image: Image.Image, target_size, allowed_bbox=None):
    image = image.resize(target_size, Image.Resampling.LANCZOS)
    arr = np.array(image, dtype=np.uint8)
    alpha = arr[:, :, 3]
    alpha[alpha < 7] = 0
    alpha[alpha > 248] = 255
    if allowed_bbox is not None:
        x0, y0, x1, y1 = allowed_bbox
        alpha[:y0] = 0
        alpha[y1 + 1 :] = 0
        alpha[:, :x0] = 0
        alpha[:, x1 + 1 :] = 0
    arr[:, :, 3] = alpha
    # Transparent RGB is zero to prevent matte fringes in engines.
    arr[alpha == 0, :3] = 0
    return Image.fromarray(arr, "RGBA")


def png_bytes(image: Image.Image):
    stream = io.BytesIO()
    image.save(stream, "PNG", optimize=True)
    return stream.getvalue()


def webp_bytes(image: Image.Image):
    stream = io.BytesIO()
    image.save(stream, "WEBP", quality=88, method=6, exact=True, lossless=False, alpha_quality=100)
    return stream.getvalue()


def save_pair(high: Image.Image, rel_dir: str, filename: str, target_size, source_size, allowed_bbox=None):
    src = clean_alpha(high, source_size, tuple(v * 2 for v in allowed_bbox) if allowed_bbox else None)
    target = clean_alpha(high, target_size, allowed_bbox)
    src_path = SRC_ROOT / rel_dir / (filename + ".png")
    webp_path = ASSET_ROOT / rel_dir / (filename + ".webp")
    atomic_write(src_path, png_bytes(src))
    data = webp_bytes(target)
    atomic_write(webp_path, data)
    return webp_path, src_path


def save_regular_stage(stage: str):
    body = build_body(stage)
    lid = build_lid(stage, False)
    lid_inner = build_lid(stage, True)
    closed = build_closed(body, lid)
    open_image = build_open(stage, body)
    light = build_light(stage)
    rays = build_rays(stage)
    card = build_card_front(stage)
    base = f"chest-{stage}"
    paths = []
    paths += list(save_pair(body, stage, base + "-body", REGULAR_SIZE, REGULAR_SOURCE, (56, 200, 456, 452)))
    paths += list(save_pair(lid, stage, base + "-lid", REGULAR_SIZE, REGULAR_SOURCE, (56, 92, 456, 252)))
    paths += list(save_pair(lid_inner, stage, base + "-lid-inner", REGULAR_SIZE, REGULAR_SOURCE, (56, 92, 456, 252)))
    paths += list(save_pair(closed, stage, base + "-closed", REGULAR_SIZE, REGULAR_SOURCE, (56, 92, 456, 452)))
    paths += list(save_pair(open_image, stage, base + "-open", REGULAR_SIZE, REGULAR_SOURCE, (0, 24, 511, 511)))
    paths += list(save_pair(light, stage, base + "-light", REGULAR_SIZE, REGULAR_SOURCE))
    paths += list(save_pair(rays, stage, base + "-rays", RAYS_SIZE, RAYS_SOURCE))
    paths += list(save_pair(card, stage, f"chest-card-front-{stage}", CARD_SIZE, CARD_SOURCE))
    return paths


def save_shared():
    paths = []
    paths += list(save_pair(build_shadow(), "shared", "chest-shadow", (512, 256), (1024, 512)))
    paths += list(save_pair(build_sparkle(), "shared", "chest-sparkle", (128, 128), (256, 256)))
    paths += list(save_pair(build_card_back(), "shared", "chest-card-back", CARD_SIZE, CARD_SOURCE))
    return paths


def chunk_exists(data: bytes, name: bytes):
    # RIFF chunks can be nested inside WEBP but VP8X/ALPH/VP8 are top-level.
    return name in data


def alpha_bbox(image: Image.Image, threshold=8):
    a = np.asarray(image.getchannel("A"))
    ys, xs = np.where(a > threshold)
    if not len(xs):
        return None
    return (int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max()))


def halo_max_distance(image: Image.Image):
    a = np.asarray(image.getchannel("A"))
    solid = a == 255
    semi = (a > 0) & (a < 255)
    if not semi.any():
        return 0.0
    if not solid.any():
        return float("inf")
    distances = distance_transform_edt(~solid)
    return float(distances[semi].max())


def composite_difference(body: Image.Image, lid: Image.Image, closed: Image.Image):
    comp = Image.new("RGBA", body.size, (0, 0, 0, 0))
    comp.alpha_composite(body)
    comp.alpha_composite(lid)
    ca = np.asarray(comp).astype(np.int16)
    cb = np.asarray(closed).astype(np.int16)
    opaque = cb[:, :, 3] > 8
    if not opaque.any():
        return 999.0
    return float(np.abs(ca[:, :, :3] - cb[:, :, :3])[opaque].mean() / 255.0)


def validation_rows(stages=STAGES, include_shared=True):
    rows = []
    common_bbox = None
    for stage in stages:
        folder = ASSET_ROOT / stage
        images = {}
        for p in sorted(folder.glob("*.webp")):
            im = Image.open(p).convert("RGBA")
            images[p.stem] = im
            data = p.read_bytes()
            bbox = alpha_bbox(im)
            corners = [np.asarray(im.getchannel("A"))[y : y + 16, x : x + 16].max() for x, y in ((0, 0), (im.width - 16, 0), (0, im.height - 16), (im.width - 16, im.height - 16))]
            row = {
                "stage": stage,
                "file": p.name,
                "width": im.width,
                "height": im.height,
                "alpha": "A" in im.getbands(),
                "corner_alpha_max": int(max(corners)),
                "bbox": bbox,
                "bbox_center_x": None if bbox is None else round((bbox[0] + bbox[2]) / 2, 2),
                "halo_max_px": None,
                "vp8x": chunk_exists(data, b"VP8X"),
                "alph_chunk": chunk_exists(data, b"ALPH"),
                "status": "PASS",
                "notes": [],
            }
            if p.name.endswith(("-body.webp", "-lid.webp", "-lid-inner.webp", "-closed.webp")):
                row["halo_max_px"] = round(halo_max_distance(im), 3)
            rows.append(row)

        body = images[f"chest-{stage}-body"]
        lid = images[f"chest-{stage}-lid"]
        inner = images[f"chest-{stage}-lid-inner"]
        closed = images[f"chest-{stage}-closed"]
        open_image = images[f"chest-{stage}-open"]
        body_bbox = alpha_bbox(body)
        lid_bbox = alpha_bbox(lid)
        inner_bbox = alpha_bbox(inner)
        closed_bbox = alpha_bbox(closed)
        open_bbox = alpha_bbox(open_image)
        if common_bbox is None:
            common_bbox = closed_bbox
        diff = composite_difference(body, lid, closed)
        for row in rows:
            if row["stage"] == stage and row["file"] == f"chest-{stage}-closed.webp":
                row["composite_mean_abs_rgb"] = round(diff, 8)
                row["closed_bbox_delta_common"] = tuple(abs(closed_bbox[i] - common_bbox[i]) for i in range(4))
        # Constraints from the brief.
        checks = []
        checks.append((body_bbox[0] >= 50 and body_bbox[2] <= 462 and 190 <= body_bbox[1] <= 210 and 446 <= body_bbox[3] <= 458, "body bbox"))
        checks.append((lid_bbox[0] >= 50 and lid_bbox[2] <= 462 and 86 <= lid_bbox[1] <= 98 and 246 <= lid_bbox[3] <= 258, "lid bbox"))
        checks.append((all(abs(inner_bbox[i] - lid_bbox[i]) <= 3 for i in range(4)), "lid-inner silhouette"))
        checks.append((closed_bbox[0] >= 50 and closed_bbox[2] <= 462 and 86 <= closed_bbox[1] <= 98 and 446 <= closed_bbox[3] <= 458, "closed bbox"))
        checks.append((open_bbox is not None and open_bbox[1] >= 24, "open top"))
        checks.append((diff < 3 / 255, "closed composite"))
        checks.append((max(abs(closed_bbox[i] - common_bbox[i]) for i in range(4)) <= 8, "closed common delta"))
        assert all(ok for ok, _ in checks), (stage, [(name, ok) for ok, name in checks], body_bbox, lid_bbox, inner_bbox, closed_bbox, diff)

    # Shared assets.
    shared_paths = sorted((ASSET_ROOT / "shared").glob("*.webp")) if include_shared else []
    for p in shared_paths:
        im = Image.open(p).convert("RGBA")
        data = p.read_bytes()
        a = np.asarray(im.getchannel("A"))
        corners = [a[y : y + 16, x : x + 16].max() for x, y in ((0, 0), (im.width - 16, 0), (0, im.height - 16), (im.width - 16, im.height - 16))]
        rows.append({"stage": "shared", "file": p.name, "width": im.width, "height": im.height, "alpha": True, "corner_alpha_max": int(max(corners)), "bbox": alpha_bbox(im), "bbox_center_x": None, "halo_max_px": None, "vp8x": chunk_exists(data, b"VP8X"), "alph_chunk": chunk_exists(data, b"ALPH"), "status": "PASS", "notes": []})
    return rows


def validate_exact(rows, stages=STAGES):
    row_map = {(r["stage"], r["file"]): r for r in rows}
    errors = []
    for r in rows:
        expected = CARD_SIZE if r["file"].startswith("chest-card") else (512, 256) if r["file"] == "chest-shadow.webp" else (128, 128) if r["file"] == "chest-sparkle.webp" else RAYS_SIZE if r["file"].endswith("-rays.webp") else REGULAR_SIZE
        if (r["width"], r["height"]) != expected:
            errors.append(f"{r['file']}: size")
        if not r["alpha"] or r["corner_alpha_max"] != 0:
            errors.append(f"{r['file']}: alpha/corners")
        if not r["vp8x"] or not r["alph_chunk"]:
            errors.append(f"{r['file']}: VP8X/ALPH")
        if r["halo_max_px"] is not None and r["halo_max_px"] > 3.0:
            errors.append(f"{r['file']}: halo {r['halo_max_px']}")
        if r["stage"] in STAGES and r["bbox"] and r["file"].endswith(("-body.webp", "-lid.webp", "-lid-inner.webp", "-closed.webp")):
            if abs(r["bbox_center_x"] - 256) > 4:
                errors.append(f"{r['file']}: symmetry")

    # Light radius and rays borders.
    for stage in stages:
        light = np.asarray(Image.open(ASSET_ROOT / stage / f"chest-{stage}-light.webp").convert("RGBA"))[:, :, 3]
        yy, xx = np.mgrid[0:512, 0:512]
        outside = np.sqrt((xx - 256) ** 2 + (yy - 230) ** 2) > 240
        if light[outside].max(initial=0) > 8:
            errors.append(f"{stage}: light outside radius")
        rays = np.asarray(Image.open(ASSET_ROOT / stage / f"chest-{stage}-rays.webp").convert("RGBA"))[:, :, 3]
        margin = math.ceil(1024 * 0.05)
        if max(rays[:margin].max(initial=0), rays[-margin:].max(initial=0), rays[:, :margin].max(initial=0), rays[:, -margin:].max(initial=0)) != 0:
            errors.append(f"{stage}: rays outer 5%")
        cy = cx = 512
        inner = np.sqrt((np.arange(1024)[None, :] - cx) ** 2 + (np.arange(1024)[:, None] - cy) ** 2) < 80
        if rays[inner].mean() > 8:
            errors.append(f"{stage}: rays center")
    if errors:
        raise AssertionError("\n".join(errors))


def make_control_composites():
    PREVIEW_ROOT.mkdir(parents=True, exist_ok=True)
    font_path = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
    bold_path = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
    font = ImageFont.truetype(font_path, 22)
    bold = ImageFont.truetype(bold_path, 28)
    for stage in STAGES:
        names = ["body", "light", "lid", "closed", "open"]
        ims = [Image.open(ASSET_ROOT / stage / f"chest-{stage}-{name}.webp").convert("RGBA") for name in names]
        board = Image.new("RGB", (5 * 540 + 40, 650), "#0b1728")
        d = ImageDraw.Draw(board)
        d.text((24, 18), stage.upper(), font=bold, fill="#f4d784")
        for i, (name, im) in enumerate(zip(names, ims)):
            x = 20 + i * 540
            # checker makes alpha and fringes visible.
            tile = Image.new("RGB", (512, 512), "#d8dde5")
            td = ImageDraw.Draw(tile)
            for yy in range(0, 512, 32):
                for xx in range(0, 512, 32):
                    if (xx // 32 + yy // 32) % 2:
                        td.rectangle((xx, yy, xx + 31, yy + 31), fill="#aeb8c5")
            tile.paste(im, (0, 0), im)
            board.paste(tile, (x, 75))
            d.text((x + 8, 598), name, font=font, fill="#e8edf5")
        path = PREVIEW_ROOT / f"control-{stage}.png"
        atomic_write(path, png_bytes(board.convert("RGBA")))


def write_reports(rows):
    OUT.mkdir(parents=True, exist_ok=True)
    file_paths = sorted(p for p in ASSET_ROOT.rglob("*") if p.is_file())
    atomic_write(OUT / "file-list.txt", ("\n".join(str(p.relative_to(OUT)) for p in file_paths) + "\n").encode())
    atomic_write(OUT / "validation-report.json", json.dumps(rows, ensure_ascii=False, indent=2, default=list).encode())
    fields = ["stage", "file", "width", "height", "alpha", "corner_alpha_max", "bbox", "bbox_center_x", "halo_max_px", "vp8x", "alph_chunk", "composite_mean_abs_rgb", "closed_bbox_delta_common", "status"]
    stream = io.StringIO()
    writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
    writer.writeheader()
    for row in rows:
        writer.writerow(row)
    atomic_write(OUT / "validation-report.csv", stream.getvalue().encode())

    lines = ["# DiceDuel chest asset validation", "", "All tolerances are the fixed values from the brief.", "", "| stage | file | px | bbox alpha>8 | center x | corner alpha | halo px | VP8X/ALPH | composite MAD | result |", "|---|---|---:|---|---:|---:|---:|---|---:|---|"]
    for r in rows:
        lines.append(f"| {r['stage']} | {r['file']} | {r['width']}×{r['height']} | {r['bbox']} | {r['bbox_center_x'] or ''} | {r['corner_alpha_max']} | {r['halo_max_px'] if r['halo_max_px'] is not None else ''} | {'yes' if r['vp8x'] and r['alph_chunk'] else 'no'} | {r.get('composite_mean_abs_rgb','')} | {r['status']} |")
    atomic_write(OUT / "validation-report.md", ("\n".join(lines) + "\n").encode())


def make_zip():
    zip_path = ROOT / "output" / "diceduel-chest-assets.zip"
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, "w", zipfile.ZIP_DEFLATED, compresslevel=7) as archive:
        for path in sorted(p for p in OUT.rglob("*") if p.is_file()):
            archive.writestr("diceduel-chest-assets/" + str(path.relative_to(OUT)), path.read_bytes())
        for script in (Path(__file__), Path(__file__).with_name("validate-chest-assets.py")):
            archive.writestr("diceduel-chest-assets/tools/" + script.name, script.read_bytes())
    data = stream.getvalue()
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        assert archive.testzip() is None
    atomic_write(zip_path, data)
    return zip_path


def clean_output():
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True)


def main():
    clean_output()
    print("building common", flush=True)
    save_regular_stage("common")
    # Enforce the requested workflow: common is measured before other stages exist.
    common_rows = validation_rows(("common",), include_shared=False)
    validate_exact(common_rows, ("common",))
    print("common PASS", flush=True)

    for stage in STAGES[1:]:
        print(f"building {stage}", flush=True)
        save_regular_stage(stage)
    save_shared()
    rows = validation_rows()
    validate_exact(rows)
    make_control_composites()
    write_reports(rows)
    zip_path = make_zip()
    print(json.dumps({"status": "PASS", "webp_files": len(list(ASSET_ROOT.glob("*/*.webp"))), "png_sources": len(list(SRC_ROOT.glob("*/*.png"))), "zip": str(zip_path), "zip_bytes": zip_path.stat().st_size}, indent=2), flush=True)


if __name__ == "__main__":
    main()
