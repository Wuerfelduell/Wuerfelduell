#!/usr/bin/env python3
from __future__ import annotations

import importlib.util
from pathlib import Path


HERE = Path(__file__).resolve().parent
BUILD = HERE / "build-chest-assets.py"
spec = importlib.util.spec_from_file_location("chest_builder", BUILD)
module = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(module)

rows = module.validation_rows()
module.validate_exact(rows)
module.write_reports(rows)
print(f"PASS: {len(rows)} WebP files validated")
